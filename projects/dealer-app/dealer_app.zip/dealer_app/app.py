#!/usr/bin/env python3
"""Сайт дилера: учёт продаж, поставок, расходов + дашборд. Только стандартная библиотека Python.
Запуск:  python app.py   → откроется http://localhost:8000   (база: dealer.db рядом с этим файлом)"""
import datetime, json, os, re, sqlite3, sys, threading, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "dealer.db")
SCHEMA = """
CREATE TABLE IF NOT EXISTS customers(customer_id INTEGER PRIMARY KEY, customer_name TEXT NOT NULL, customer_type TEXT NOT NULL, region TEXT NOT NULL, registration_date TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS transactions(transaction_id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL REFERENCES customers(customer_id), transaction_date TEXT NOT NULL, amount REAL NOT NULL, amount_paid REAL NOT NULL);
CREATE TABLE IF NOT EXISTS deliveries(delivery_id INTEGER PRIMARY KEY, delivery_date TEXT NOT NULL, supplier TEXT NOT NULL, description TEXT, amount REAL NOT NULL, amount_paid REAL NOT NULL);
CREATE TABLE IF NOT EXISTS expenses(expense_id INTEGER PRIMARY KEY, expense_date TEXT NOT NULL, category TEXT NOT NULL, description TEXT, amount REAL NOT NULL);
"""
# таблица: (первичный ключ, {поле: тип})  s=текст, o=необязательный текст, d=дата, n=число ≥ 0, i=id
CFG = {
    "customers": ("customer_id", dict(customer_name="s", customer_type="s", region="s", registration_date="d")),
    "transactions": ("transaction_id", dict(customer_id="i", transaction_date="d", amount="n", amount_paid="n")),
    "deliveries": ("delivery_id", dict(delivery_date="d", supplier="s", description="o", amount="n", amount_paid="n")),
    "expenses": ("expense_id", dict(expense_date="d", category="s", description="o", amount="n")),
}

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db():
    with conn() as c:
        c.executescript(SCHEMA)
        for t in CFG:  # кто внёс запись
            if "entered_by" not in [r[1] for r in c.execute(f"PRAGMA table_info({t})")]:
                c.execute(f"ALTER TABLE {t} ADD COLUMN entered_by TEXT")

RU = dict(customer_name="Название", customer_type="Тип", region="Регион", registration_date="Дата регистрации", customer_id="Клиент",
          transaction_date="Дата", amount="Сумма", amount_paid="Оплачено", delivery_date="Дата", supplier="Поставщик", expense_date="Дата", category="Категория")

def clean(table, body):
    pk, spec = CFG[table]
    out = {}
    for f, t in spec.items():
        v = body.get(f)
        if t == "d" and not v and f == "registration_date":
            v = datetime.date.today().isoformat()
        if t in "sdni" and (v is None or str(v).strip() == ""):
            raise ValueError(f"Поле «{RU.get(f, f)}» обязательно")
        if t == "d":
            try: datetime.date.fromisoformat(str(v))
            except ValueError: raise ValueError(f"Неверная дата в поле «{RU.get(f, f)}»")
        elif t == "n":
            try: v = float(v)
            except (TypeError, ValueError): raise ValueError(f"В поле «{RU.get(f, f)}» нужно число")
            if v < 0: raise ValueError(f"Поле «{RU.get(f, f)}» не может быть отрицательным")
        elif t == "i": v = int(v)
        else: v = (str(v).strip() if v else "")[:200]
        out[f] = v
    if "amount_paid" in out and out["amount_paid"] > out["amount"]:
        raise ValueError("Оплачено больше суммы")
    if "amount" in out and table != "customers" and out["amount"] <= 0:
        raise ValueError("Сумма должна быть больше нуля")
    out["entered_by"] = str(body.get("entered_by") or "")[:60]
    return out

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send(self, code, obj, ctype="application/json"):
        data = obj if isinstance(obj, bytes) else json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")
    def do_GET(self):
        if self.path in ("/", "/index.html"):
            return self.send(200, open(os.path.join(HERE, "index.html"), "rb").read(), "text/html")
        if self.path == "/api/data":
            with conn() as c:
                return self.send(200, {t: [dict(r) for r in c.execute(f"SELECT * FROM {t}")] for t in CFG})
        self.send(404, {"error": "не найдено"})
    def do_POST(self):
        try:
            m = re.fullmatch(r"/api/(\w+)", self.path); b = self.body()
            if m and m[1] == "pay":  # принять оплату по долгу
                with conn() as c:
                    r = c.execute("SELECT amount, amount_paid FROM transactions WHERE transaction_id=?", (b.get("id"),)).fetchone()
                    pay = float(b.get("pay", 0))
                    if not r or pay <= 0 or r["amount_paid"] + pay > r["amount"] + 0.01:
                        raise ValueError("Неверная сумма оплаты")
                    c.execute("UPDATE transactions SET amount_paid=amount_paid+? WHERE transaction_id=?", (pay, b["id"]))
                return self.send(200, {"ok": True})
            if not m or m[1] not in CFG: return self.send(404, {"error": "не найдено"})
            d = clean(m[1], b); cols = ",".join(d)
            with conn() as c:
                cur = c.execute(f"INSERT INTO {m[1]}({cols}) VALUES({','.join('?' * len(d))})", list(d.values()))
            self.send(200, {"id": cur.lastrowid})
        except (ValueError, sqlite3.Error, json.JSONDecodeError) as e:
            self.send(400, {"error": str(e)})
    def do_DELETE(self):
        m = re.fullmatch(r"/api/(\w+)/(\d+)", self.path)
        if not m or m[1] not in CFG: return self.send(404, {"error": "не найдено"})
        try:
            with conn() as c:
                c.execute(f"DELETE FROM {m[1]} WHERE {CFG[m[1]][0]}=?", (m[2],))
            self.send(200, {"ok": True})
        except sqlite3.IntegrityError:
            self.send(400, {"error": "Нельзя удалить: у клиента есть продажи"})

if __name__ == "__main__":
    init_db()
    host = "0.0.0.0" if "--lan" in sys.argv else "127.0.0.1"  # --lan: доступ с других компьютеров офиса (без пароля!)
    port = 8000
    url = f"http://localhost:{port}"
    print(f"Сайт запущен: {url}   (остановить: Ctrl+C)")
    threading.Timer(1, lambda: webbrowser.open(url)).start()
    ThreadingHTTPServer((host, port), H).serve_forever()
