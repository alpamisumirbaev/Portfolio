@echo off
chcp 65001 >nul
py app.py || python app.py
pause
